import os
import django

# Cấu hình môi trường Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'BTL.settings')  # Thay 'BTL' bằng tên thư mục chứa settings.py
django.setup()

from django.contrib.auth.models import User
from main.models import Quiz, Question, Answer

# Lấy người dùng đầu tiên trong hệ thống
user = User.objects.first()  # Đảm bảo ít nhất 1 người dùng tồn tại

# Dữ liệu mẫu
quizzes_data = [
    {
        "title": "Kiến thức cơ bản về Python",
        "description": "Bài kiểm tra dành cho người mới học Python",
        "category": "Python",
        "questions": [
            {
                "text": "Python là ngôn ngữ lập trình gì?",
                "answers": [
                    {"text": "Ngôn ngữ lập trình bậc cao", "is_correct": True},
                    {"text": "Ngôn ngữ lập trình máy", "is_correct": False},
                    {"text": "Ngôn ngữ lập trình trung gian", "is_correct": False},
                ],
            },
            {
                "text": "Câu lệnh nào để in ra màn hình trong Python?",
                "answers": [
                    {"text": "echo", "is_correct": False},
                    {"text": "print", "is_correct": True},
                    {"text": "log", "is_correct": False},
                ],
            },
            {
                "text": "Biến trong Python được khai báo như thế nào?",
                "answers": [
                    {"text": "var x = 5", "is_correct": False},
                    {"text": "x = 5", "is_correct": True},
                    {"text": "int x = 5", "is_correct": False},
                ],
            },
            {
                "text": "Phần mở rộng của tệp Python là gì?",
                "answers": [
                    {"text": ".py", "is_correct": True},
                    {"text": ".java", "is_correct": False},
                    {"text": ".c", "is_correct": False},
                ],
            },
            {
                "text": "Python có phải là ngôn ngữ lập trình thông dịch không?",
                "answers": [
                    {"text": "Có", "is_correct": True},
                    {"text": "Không", "is_correct": False},
                ],
            },
        ],
    },
{
        "title": "Kiến thức cơ bản về CSS",
        "description": "Bài kiểm tra dành cho người mới học CSS",
        "category": "CSS",
        "questions": [
            {
                "text": "CSS viết tắt của từ gì?",
                "answers": [
                    {"text": "Cascading Style Sheets", "is_correct": True},
                    {"text": "Creative Style Sheets", "is_correct": False},
                    {"text": "Coded Style Sheets", "is_correct": False},
                ],
            },
            {
                "text": "Thuộc tính nào để thay đổi màu chữ?",
                "answers": [
                    {"text": "color", "is_correct": True},
                    {"text": "text-color", "is_correct": False},
                    {"text": "font-color", "is_correct": False},
                ],
            },
            {
                "text": "Thuộc tính nào để thay đổi kích thước font?",
                "answers": [
                    {"text": "font-size", "is_correct": True},
                    {"text": "size", "is_correct": False},
                    {"text": "text-size", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh CSS nào để căn giữa nội dung?",
                "answers": [
                    {"text": "text-align: center;", "is_correct": True},
                    {"text": "align-text: center;", "is_correct": False},
                    {"text": "center-align: text;", "is_correct": False},
                ],
            },
            {
                "text": "Thuộc tính nào để tạo khoảng cách giữa các phần tử?",
                "answers": [
                    {"text": "margin", "is_correct": True},
                    {"text": "padding", "is_correct": False},
                    {"text": "spacing", "is_correct": False},
                ],
            },
        ],
    },
    {
        "title": "Kiến thức cơ bản về JavaScript",
        "description": "Bài kiểm tra dành cho người mới học JavaScript",
        "category": "JavaScript",
        "questions": [
            {
                "text": "JavaScript là ngôn ngữ gì?",
                "answers": [
                    {"text": "Ngôn ngữ lập trình", "is_correct": True},
                    {"text": "Ngôn ngữ đánh dấu", "is_correct": False},
                    {"text": "Ngôn ngữ máy", "is_correct": False},
                ],
            },
            {
                "text": "Cách khai báo biến trong JavaScript?",
                "answers": [
                    {"text": "var", "is_correct": True},
                    {"text": "let", "is_correct": True},
                    {"text": "int", "is_correct": False},
                ],
            },
            {
                "text": "Hàm nào dùng để hiển thị thông báo trên trình duyệt?",
                "answers": [
                    {"text": "alert()", "is_correct": True},
                    {"text": "notify()", "is_correct": False},
                    {"text": "prompt()", "is_correct": False},
                ],
            },
            {
                "text": "Phương thức nào để thêm phần tử vào cuối mảng?",
                "answers": [
                    {"text": "push()", "is_correct": True},
                    {"text": "pop()", "is_correct": False},
                    {"text": "append()", "is_correct": False},
                ],
            },
            {
                "text": "Câu lệnh nào để kiểm tra điều kiện?",
                "answers": [
                    {"text": "if", "is_correct": True},
                    {"text": "for", "is_correct": False},
                    {"text": "while", "is_correct": False},
                ],
            },
        ],
    },
    {
        "title": "Kiến thức cơ bản về SQL",
        "description": "Bài kiểm tra dành cho người mới học SQL",
        "category": "SQL",
        "questions": [
            {
                "text": "SQL viết tắt của từ gì?",
                "answers": [
                    {"text": "Structured Query Language", "is_correct": True},
                    {"text": "Standard Query Language", "is_correct": False},
                    {"text": "Sequential Query Language", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để chọn tất cả các cột trong bảng?",
                "answers": [
                    {"text": "SELECT * FROM table", "is_correct": True},
                    {"text": "GET ALL FROM table", "is_correct": False},
                    {"text": "SELECT ALL FROM table", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để xóa dữ liệu trong bảng?",
                "answers": [
                    {"text": "DELETE FROM table", "is_correct": True},
                    {"text": "REMOVE FROM table", "is_correct": False},
                    {"text": "DROP TABLE table", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để thêm dữ liệu vào bảng?",
                "answers": [
                    {"text": "INSERT INTO table", "is_correct": True},
                    {"text": "ADD INTO table", "is_correct": False},
                    {"text": "UPDATE table", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để sắp xếp kết quả theo thứ tự tăng dần?",
                "answers": [
                    {"text": "ORDER BY column ASC", "is_correct": True},
                    {"text": "SORT BY column ASC", "is_correct": False},
                    {"text": "ARRANGE BY column ASC", "is_correct": False},
                ],
            },
        ],
    },
    {
        "title": "Kiến thức cơ bản về Git",
        "description": "Bài kiểm tra dành cho người mới học Git",
        "category": "Git",
        "questions": [
            {
                "text": "Git là gì?",
                "answers": [
                    {"text": "Hệ thống quản lý phiên bản phân tán", "is_correct": True},
                    {"text": "Hệ quản trị cơ sở dữ liệu", "is_correct": False},
                    {"text": "Ngôn ngữ lập trình", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để sao chép repository từ GitHub?",
                "answers": [
                    {"text": "git clone", "is_correct": True},
                    {"text": "git pull", "is_correct": False},
                    {"text": "git fetch", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để kiểm tra trạng thái repository?",
                "answers": [
                    {"text": "git status", "is_correct": True},
                    {"text": "git log", "is_correct": False},
                    {"text": "git branch", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để lưu thay đổi vào repository cục bộ?",
                "answers": [
                    {"text": "git commit", "is_correct": True},
                    {"text": "git add", "is_correct": False},
                    {"text": "git push", "is_correct": False},
                ],
            },
            {
                "text": "Lệnh nào để tải thay đổi từ repository từ xa?",
                "answers": [
                    {"text": "git pull", "is_correct": True},
                    {"text": "git fetch", "is_correct": False},
                    {"text": "git clone", "is_correct": False},
                ],
            },
        ],
    },
]

# Tạo bài kiểm tra, câu hỏi và câu trả lời
for quiz_data in quizzes_data:
    quiz = Quiz.objects.create(
        title=quiz_data["title"],
        description=quiz_data["description"],
        category=quiz_data["category"],
        created_by=user,  # Thêm người dùng vào trường created_by
    )
    for question_data in quiz_data["questions"]:
        question = Question.objects.create(quiz=quiz, text=question_data["text"])
        for answer_data in question_data["answers"]:
            Answer.objects.create(
                question=question, text=answer_data["text"], is_correct=answer_data["is_correct"]
            )

print("Đã tạo xong bài kiểm tra!")
